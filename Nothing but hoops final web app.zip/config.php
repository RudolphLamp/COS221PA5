<?php

// Define database connection constants
define("DB_HOST", "wheatley.cs.up.ac.za"); 
define("DB_USER", "u23536013"); 
define("DB_PASSWORD", "CB5XXQPCTLSTGWLHVKFOWOET6R6W2UXC"); 
define("DB_NAME", "u23536013_final_prac_5_database"); 
?>