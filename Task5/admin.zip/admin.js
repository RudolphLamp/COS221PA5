window.onload = function() {
  document.getElementById('removeButton').addEventListener('click', function(event) {
    event.preventDefault();
    
    var titleId = document.getElementById('removeTitleID').value;
    
    var data = {
      "type": "DeleteMovieOrSeries",
      "Title_ID": titleId
    };
    
    var jsonData = JSON.stringify(data);
    
    alert(jsonData);
    console.log(jsonData);

    // Create a new XMLHttpRequest object
    var xmlReq = new XMLHttpRequest();

    // Define what happens on successful data submission
    xmlReq.addEventListener('load', function(event) {
      alert('DELETED!');
    });

    // Define what happens in case of error
    xmlReq.addEventListener('error', function(event) {
      alert('Oops! Something went wrong.');
    });

    // Set up our request
    xmlReq.open("POST", "https://wheatley.cs.up.ac.za/u20598425/cos221/api.php", true);
    xmlReq.setRequestHeader("Content-Type", "application/json");
    xmlReq.setRequestHeader("Authorization", "Basic " + btoa('u20598425:Spookruds44$$$'));

    // Send our request
    xmlReq.send(jsonData);
  });
}


  document.addEventListener('DOMContentLoaded', (event) => {
    document.getElementById('updateButton').addEventListener('click', function(event) {
      event.preventDefault();
      
      var data = {
          "type": "UpdateMovieOrSeries",
          "Title_ID": document.getElementById('updateTitleID').value
        };
        
        var fields = ['Title_Name', 'Content_Rating_ID', 'Content_Rating_ID', 'Review_Rating', 'Release_Date', 'Plot_Summary', 'Image', 'Language_ID'];
        
        fields.forEach(function(field) {
          var element = document.getElementById(field);
          if (element && element.value) {
            data[field] = element.value;
          }
        });
        
  
      var isMovieCheckbox = document.getElementById('updateType');
      if (isMovieCheckbox && isMovieCheckbox.checked) {
        data['isMovie'] = 1;
      } else {
        data['isMovie'] = 0;
      }
      
      var jsonData = JSON.stringify(data);
      
      alert(jsonData);
      console.log(jsonData);
  
      // Create a new XMLHttpRequest object
      var xmlReq = new XMLHttpRequest();
  
      // Define what happens on successful data submission
      xmlReq.addEventListener('load', function(event) {
        alert('UPDATED!.');
      });
  
      // Define what happens in case of error
      xmlReq.addEventListener('error', function(event) {
        alert('Oops! Something went wrong.');
      });
  
      // Set up our request
      xmlReq.open("POST", "https://wheatley.cs.up.ac.za/u20598425/cos221/api.php", true);
      xmlReq.setRequestHeader("Content-Type", "application/json");
      xmlReq.setRequestHeader("Authorization", "Basic " + btoa('u20598425:Spookruds44$$$'));
  
      // Send our request
      xmlReq.send(jsonData);
    });
  });



window.onload = function() {
  document.getElementById('addButton').addEventListener('click', function(event) {
    event.preventDefault();
  
    var data = {
      "type": "InsertMovieOrSeries",
      "Title_Name": document.getElementById('titleNameaa').value,
      "Content_Rating_ID": document.getElementById('contentRatingIDaa').value,
      "Review_Rating": document.getElementById('reviewRatingaa').value,
      "Release_Date": document.getElementById('releaseDateaa').value,
      "Plot_Summary": document.getElementById('plotSummaryaa').value,
      "Image": document.getElementById('imageaa').value,
      "Language_ID": document.getElementById('languageIDaa').value,
    };

    for (var key in data) {
      if (data[key] === '') {
        alert(key + ' must not be empty');
        return; 
      }
    }

    var isMovieCheckbox = document.getElementById('typeadd');
    if (isMovieCheckbox && isMovieCheckbox.checked) {
      data['isMovie'] = 1;
    } else {
      data['isMovie'] = 0;
    }
    
    var jsonData = JSON.stringify(data);
    alert(jsonData);
    console.log(jsonData);
    
    // Create a new XMLHttpRequest object
    var xmlReq = new XMLHttpRequest();

    // Define what happens on successful data submission
    xmlReq.addEventListener('load', function(event) {
      alert(document.getElementById('titleNameaa').value + ' has been added to the database.');
    });

    // Define what happens in case of error
    xmlReq.addEventListener('error', function(event) {
      alert('Oops! Something went wrong.');
    });

    // Set up our request
    xmlReq.open("POST", "https://wheatley.cs.up.ac.za/u20598425/cos221/api.php", true);
    xmlReq.setRequestHeader("Content-Type", "application/json");
    xmlReq.setRequestHeader("Authorization", "Basic " + btoa('u20598425:Spookruds44$$$'));

    // Send our request
    xmlReq.send(jsonData);
  });
}