

document.getElementById('removeButton').addEventListener('click', function(event) {
    event.preventDefault();

    let data = {
        "type": "RemoveMovieOrSeries",
        "Title_ID": document.getElementById('removeTitleID').value,
    };

    fetch('api-url', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
    })
    .then(response => response.json())
    .then(data => {
        console.log('Success:', data);
    })
    .catch((error) => {
        console.error('Error:', error);
    });
});