<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include_once 'config.php';
class API {
    

    public function register($firstName, $lastName, $email, $password, $dateOfBirth, $adminPrivileges) {
        global $mysqli;
        // Validate the email
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return json_encode(['status' => 'error', 'message' => 'Invalid email']);
        }
        // Validate the password
        if (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/', $password)) {
            return json_encode(['status' => 'error', 'message' => 'Password must have at least 8 characters with at least one uppercase letter, one number, one special character, and one lowercase letter.']);
        }
        // Check if the user already exists
        $stmt = $mysqli->prepare("SELECT * FROM User_Account WHERE Email_Address = ?");
        if ($stmt === false) {
            die('prepare() failed: ' . htmlspecialchars($mysqli->error));
        }
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            return json_encode(['status' => 'error', 'message' => 'User already exists']);
        }
    
        // Hash the password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    
        // Insert the new user into the database
        $stmt = $mysqli->prepare("INSERT INTO User_Account (First_Name, Last_Name, Email_Address, User_Password, Date_of_Birth, Admin_Privileges) VALUES (?, ?, ?, ?, ?, ?)");
        if ($stmt === false) {
            die('prepare() failed: ' . htmlspecialchars($mysqli->error));
        }
        $stmt->bind_param("sssssi", $firstName, $lastName, $email, $hashed_password, $dateOfBirth, $adminPrivileges);
        if ($stmt->execute() === false) {
            die('execute() failed: ' . htmlspecialchars($stmt->error));
        }
    
        // Get the ID of the newly created user
        $userID = $mysqli->insert_id;
    
        // Prepare the success message
        $message = $adminPrivileges ? 'Admin successfully created' : 'User successfully created';
        return json_encode(['status' => 'success', 'timestamp' => round(microtime(true) * 1000), 'data' => ["User_ID" => $userID, "Email" => $email, "First_Name" => $firstName, "message" => $message]]);
    }
  
    
  
    public function searchMovieTitles($title) {
        global $mysqli;
    
        // Prepare the SQL statement
        $stmt = $mysqli->prepare("SELECT Title_ID, Title_Name FROM title WHERE Title_Name LIKE ?");
        if ($stmt === false) {
            die('prepare() failed: ' . htmlspecialchars($mysqli->error));
        }
    
        // Bind the title parameter
        $title = '%' . $title . '%';
        $stmt->bind_param("s", $title);
    
        $stmt->execute();
        $result = $stmt->get_result();
    
        // Fetch all the matching titles
        $titles = $result->fetch_all(MYSQLI_ASSOC);
    
        return json_encode(['status' => 'success', 'data' => $titles]);
    }



   
    
    public function insertMovieOrSeries($Title_Name, $Content_Rating_ID, $Review_Rating, $Release_Date, $Plot_Summary, $Image, $Language_ID, $isMovie) {
        global $mysqli;
    
        // Prepare the SQL statement for title table
        $stmt = $mysqli->prepare("INSERT INTO title (Title_Name, Content_Rating_ID, Review_Rating, Release_Date, Plot_Summary, Image, Language_ID) VALUES (?, ?, ?, ?, ?, ?, ?)");
        if ($stmt === false) {
            die('prepare() failed: ' . htmlspecialchars($mysqli->error));
        }
    
        // Bind the parameters
        $stmt->bind_param("sissssi", $Title_Name, $Content_Rating_ID, $Review_Rating, $Release_Date, $Plot_Summary, $Image, $Language_ID);
    
        $stmt->execute();
        $title_id = $mysqli->insert_id;
    
        // Check if isMovie
        if ($isMovie == 1) {
            // Prepare the SQL statement for movie table
            $stmt = $mysqli->prepare("INSERT INTO movie (Title_ID, Duration) VALUES (?, ?)");
            if ($stmt === false) {
                die('prepare() failed: ' . htmlspecialchars($mysqli->error));
            }
    
            // Bind the parameters
            $duration = rand(90, 127);
            $stmt->bind_param("ii", $title_id, $duration);
        } elseif ($isMovie == 0) {
            // Prepare the SQL statement for series table
            $stmt = $mysqli->prepare("INSERT INTO series (Title_ID) VALUES (?)");
            if ($stmt === false) {
                die('prepare() failed: ' . htmlspecialchars($mysqli->error));
            }
    
            // Bind the parameters
            $stmt->bind_param("i", $title_id);
        }
    
        $stmt->execute();
    
        return json_encode(['status' => 'success', 'data' => $title_id]);
    }
   


    public function updateMovieOrSeries($Title_ID, $Title_Name = null, $Content_Rating_ID = null, $Review_Rating = null, $Release_Date = null, $Plot_Summary = null, $Image = null, $Language_ID = null, $isMovie = null) {
        global $mysqli;
    
        // Prepare the SQL statement for title table
        $stmt = $mysqli->prepare("UPDATE title SET Title_Name = IFNULL(?, Title_Name), Content_Rating_ID = IFNULL(?, Content_Rating_ID), Review_Rating = IFNULL(?, Review_Rating), Release_Date = IFNULL(?, Release_Date), Plot_Summary = IFNULL(?, Plot_Summary), Image = IFNULL(?, Image), Language_ID = IFNULL(?, Language_ID) WHERE Title_ID = ?");
        if ($stmt === false) {
            die('prepare() failed: ' . htmlspecialchars($mysqli->error));
        }
    
        // Bind the parameters
        $stmt->bind_param("sisssssi", $Title_Name, $Content_Rating_ID, $Review_Rating, $Release_Date, $Plot_Summary, $Image, $Language_ID, $Title_ID);
    
        $stmt->execute();
    
        // Check if isMovie is not null
        if ($isMovie !== null) {
            // Delete from movie and series tables
            $mysqli->query("DELETE FROM movie WHERE Title_ID = $Title_ID");
            $mysqli->query("DELETE FROM series WHERE Title_ID = $Title_ID");
    
            // Insert into movie or series table
            if ($isMovie == 1) {
                // Prepare the SQL statement for movie table
                $stmt = $mysqli->prepare("INSERT INTO movie (Title_ID, Duration) VALUES (?, ?)");
                if ($stmt === false) {
                    die('prepare() failed: ' . htmlspecialchars($mysqli->error));
                }
    
                // Bind the parameters
                $duration = rand(90, 127);
                $stmt->bind_param("ii", $Title_ID, $duration);
            } elseif ($isMovie == 0) {
                // Prepare the SQL statement for series table
                $stmt = $mysqli->prepare("INSERT INTO series (Title_ID) VALUES (?)");
                if ($stmt === false) {
                    die('prepare() failed: ' . htmlspecialchars($mysqli->error));
                }
    
                // Bind the parameters
                $stmt->bind_param("i", $Title_ID);
            }
    
            $stmt->execute();
        }
    
        return json_encode(['status' => 'success', 'data' => $Title_ID]);
    }
   

  
    
    
   
    public function deleteMovieOrSeries($Title_ID) {
        global $mysqli;
    
        // Identify all tables that have a foreign key reference to `Title_ID` in the `season` table
        // For example, if `episode` table also references `Title_ID`, it should be deleted first
        // $mysqli->query("DELETE FROM episode WHERE Title_ID = $Title_ID");
    
        // Then delete from movie, series, directored_by, stars_in, and title_genre tables
        $mysqli->query("DELETE FROM movie WHERE Title_ID = $Title_ID");
        $mysqli->query("DELETE FROM series WHERE Title_ID = $Title_ID");
        $mysqli->query("DELETE FROM directored_by WHERE Title_ID = $Title_ID");
        $mysqli->query("DELETE FROM stars_in WHERE Title_ID = $Title_ID");
        $mysqli->query("DELETE FROM title_genre WHERE Title_ID = $Title_ID");
    
        // Finally, delete from season table
        $mysqli->query("DELETE FROM season WHERE Title_ID = $Title_ID");
    
        // Prepare the SQL statement for title table
        $stmt = $mysqli->prepare("DELETE FROM title WHERE Title_ID = ?");
        if ($stmt === false) {
            die('prepare() failed: ' . htmlspecialchars($mysqli->error));
        }
    
        // Bind the parameters
        $stmt->bind_param("i", $Title_ID);
    
        $stmt->execute();
    
        return json_encode(['status' => 'success', 'data' => $Title_ID]);
    }
   
    
 
    


    

   
  
    public function hashExistingPasswords() {
        global $mysqli;
    
        // Select users where User_ID is between 364 and 665
        $stmt = $mysqli->prepare("SELECT * FROM User_Account WHERE User_ID BETWEEN 999 AND 1005");
        if ($stmt === false) {
            die('prepare() failed: ' . htmlspecialchars($mysqli->error));
        }
        $stmt->execute();
        $result = $stmt->get_result();
    
        // Loop through each user
        while ($user = $result->fetch_assoc()) {
            // Hash the password
            $hashed_password = password_hash($user['User_Password'], PASSWORD_DEFAULT);
    
            // Update the user's password in the database
            $stmt = $mysqli->prepare("UPDATE User_Account SET User_Password = ? WHERE User_ID = ?");
            if ($stmt === false) {
                die('prepare() failed: ' . htmlspecialchars($mysqli->error));
            }
            $stmt->bind_param("si", $hashed_password, $user['User_ID']);
            if ($stmt->execute() === false) {
                die('execute() failed: ' . htmlspecialchars($stmt->error));
            }
        }
    
        return json_encode(['status' => 'success', 'message' => 'Passwords for users 364 to 665 have been hashed']);
    }

 
   
    
    public function getDetails($titleId) {
        global $mysqli;
    
        // Prepare the SQL statement
        $stmt = $mysqli->prepare("SELECT Title_ID, Title_Name, IFNULL(Content_Rating_ID, 0) AS Content_Rating_ID, Review_Rating, Release_Date, Plot_Summary, Crew, Image, IFNULL(Language_ID, 0) AS Language_ID FROM title WHERE Title_ID = ?");
        if ($stmt === false) {
            die('prepare() failed: ' . htmlspecialchars($mysqli->error));
        }
    
        // Bind the titleId parameter
        $stmt->bind_param("i", $titleId);
    
        $stmt->execute();
        $result = $stmt->get_result();
    
        // Fetch the movie details
        $movieDetails = $result->fetch_assoc();
    
        // Get the language name
        $stmt = $mysqli->prepare("SELECT Language_Name FROM available_language WHERE Language_ID = ?");
        if ($stmt === false) {
            die('prepare() failed: ' . htmlspecialchars($mysqli->error));
        }
    
        // Bind the languageId parameter
        $stmt->bind_param("i", $movieDetails['Language_ID']);
    
        $stmt->execute();
        $result = $stmt->get_result();
    
        // Fetch the language name
        $language = $result->fetch_assoc();
    
        // Replace the Language_ID with the Language_Name in the movie details
        $movieDetails['Language_ID'] = $language['Language_Name'];
    
        // Get the content rating
        $stmt = $mysqli->prepare("SELECT Rating FROM content_rating WHERE Content_Rating_ID = ?");
        if ($stmt === false) {
            die('prepare() failed: ' . htmlspecialchars($mysqli->error));
        }
    
        // Bind the contentRatingId parameter
        $stmt->bind_param("i", $movieDetails['Content_Rating_ID']);
    
        $stmt->execute();
        $result = $stmt->get_result();
    
        // Fetch the content rating
        $contentRating = $result->fetch_assoc();
    
        // Replace the Content_Rating_ID with the Rating in the movie details
        $movieDetails['Content_Rating_ID'] = $contentRating['Rating'];
    
        return json_encode(['status' => 'success', 'data' => $movieDetails], JSON_UNESCAPED_SLASHES);
    }
    
    



    public function login($email, $password) {
        global $mysqli;
        $stmt = $mysqli->prepare("SELECT * FROM User_Account WHERE Email_Address = ?");
        if (!$stmt) {
            return json_encode(['status' => 'error', 'message' => 'Database error: ' . $mysqli->error]);
        }
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            if (password_verify($password, $user['User_Password'])) {
                unset($user['User_Password']);
                return json_encode([
                    "status" => "success",
                    "timestamp" => round(microtime(true) * 1000),
                    "data" => [$user]
                ]);
            } else {
                return json_encode(['status' => 'error', 'message' => 'Invalid password']);
            }
        } else {
            return json_encode(['status' => 'error', 'message' => 'User does not exist']);
        }
    }
}


$api = new API();
$data = json_decode(file_get_contents('php://input'), true);
if ($data['type'] == 'Register') {
    $adminPrivileges = isset($data['Admin_Privileges']) ? $data['Admin_Privileges'] : 0;  // Use 0 as the default value
    echo $api->register($data['First_Name'], $data['Last_Name'], $data['Email_Address'], $data['User_Password'], $data['Date_of_Birth'], $adminPrivileges);
} elseif ($data['type'] == 'Login') {
    echo $api->login($data['Email_Address'], $data['User_Password']);
} elseif ($data['type'] == 'HashPasswords') {
    echo $api->hashExistingPasswords();
} elseif ($data['type'] == 'SearchTitles') {
    echo $api->searchMovieTitles($data['Title_Name']);
} elseif ($data['type'] == 'GetDetails') {
    echo $api->getDetails($data['Title_ID']);
} elseif ($data['type'] == 'InsertMovieOrSeries') {
    $keys = ['Title_Name', 'Content_Rating_ID', 'Review_Rating', 'Release_Date', 'Plot_Summary', 'Image', 'Language_ID', 'isMovie'];
    foreach ($keys as $key) {
        if (!array_key_exists($key, $data)) {
            die("Error: '$key' is missing from data");
        }
    }

    // Call insertMovieOrSeries and echo the response
    $response = $api->insertMovieOrSeries($data['Title_Name'], $data['Content_Rating_ID'], $data['Review_Rating'], $data['Release_Date'], $data['Plot_Summary'], $data['Image'], $data['Language_ID'], $data['isMovie']);
    if ($response === false) {
        die("Error: insertMovieOrSeries failed");
    }
    echo $response;
} elseif ($data['type'] == 'UpdateMovieOrSeries') {
    $keys = ['Title_ID'];
    foreach ($keys as $key) {
        if (!array_key_exists($key, $data)) {
            die("Error: '$key' is missing from data");
        }
    }

    $response = $api->updateMovieOrSeries(
        $data['Title_ID'], 
        $data['Title_Name'] ?? null, 
        $data['Content_Rating_ID'] ?? null, 
        $data['Review_Rating'] ?? null, 
        $data['Release_Date'] ?? null, 
        $data['Plot_Summary'] ?? null, 
        $data['Image'] ?? null, 
        $data['Language_ID'] ?? null, 
        $data['isMovie'] ?? null
    );

    if ($response === false) {
        die("Error: updateMovieOrSeries failed");
    }
    echo $response;
} elseif ($data['type'] == 'DeleteMovieOrSeries') {
    $keys = ['Title_ID'];
    foreach ($keys as $key) {
        if (!array_key_exists($key, $data)) {
            die("Error: '$key' is missing from data");
        }
    }

    $response = $api->deleteMovieOrSeries($data['Title_ID']);

    if ($response === false) {
        die("Error: deleteMovieOrSeries failed");
    }
    echo $response;
}








?>
