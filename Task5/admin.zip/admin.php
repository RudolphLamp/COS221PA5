<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="css/admin.css">
    <script src="admin.js"></script>
</head>
<body>

<h2>Add Movies/Series</h2>
<form method="post">
  <label for="titleName">Title Name:</label><br>
  <input type="text" id="titleName" name="titleName"><br>

  <label for="contentRatingID">Content Rating ID:</label><br>
  <input type="number" id="contentRatingID" name="contentRatingID" min="1" step="1"><br>

  <label for="reviewRating">Review Rating:</label><br>
  <input type="number" id="reviewRating" name="reviewRating" min="1" step="0.1"><br>

  <label for="releaseDate">Release Year:</label><br>
  <input type="number" id="releaseDate" name="releaseDate" min="1800" max="2099" step="1"><br>

  <label for="plotSummary">Plot Summary:</label><br>
  <textarea id="plotSummary" name="plotSummary"></textarea><br>

  <label for="image">Image URL:</label><br>
  <input type="text" id="image" name="image"><br>

  <label for="languageID">Language ID:</label><br>
  <input type="number" id="languageID" name="languageID" min="1" step="1"><br>

  <input type="checkbox" id="type" name="type" value="series">
  <label for="type"> Check if it's a series</label><br>

  <input type="submit" id="addButton" value="Submit">
</form>

<h2>Update Movies/Series</h2>
<form method="post">
  <label for="updateTitleID">Title ID:</label><br>
  <input type="number" id="updateTitleID" name="updateTitleID" min="1" step="1"><br>

  <label for="updateTitleName">Title Name:</label><br>
  <input type="text" id="updateTitleName" name="updateTitleName"><br>

  <label for="updateContentRatingID">Content Rating ID:</label><br>
  <input type="number" id="updateContentRatingID" name="updateContentRatingID" min="1" step="1"><br>

  <label for="updateReviewRating">Review Rating:</label><br>
  <input type="number" id="updateReviewRating" name="updateReviewRating" min="1" step="0.1"><br>

  <label for="updateReleaseDate">Release Year:</label><br>
  <input type="number" id="updateReleaseDate" name="updateReleaseDate" min="1800" max="2099" step="1"><br>

  <label for="updatePlotSummary">Plot Summary:</label><br>
  <textarea id="updatePlotSummary" name="updatePlotSummary"></textarea><br>

  <label for="updateImage">Image URL:</label><br>
  <input type="text" id="updateImage" name="updateImage"><br>

  <label for="updateLanguageID">Language ID:</label><br>
  <input type="number" id="updateLanguageID" name="updateLanguageID" min="1" step="1"><br>

  <input type="checkbox" id="updateType" name="updateType" value="series">
  <label for="updateType"> Check if it's a series</label><br>

  <input type="submit" id="updateButton" value="Submit">
</form>

<h2>Remove Movies/Series</h2>
<form method="post">
  <label for="removeTitleID">Title ID:</label><br>
  <input type="number" id="removeTitleID" name="removeTitleID" min="1" step="1"><br>
  <input type="submit" id="removeButton" value="Submit">
</form>

</body>
</html>