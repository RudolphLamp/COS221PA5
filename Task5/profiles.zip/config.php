<?php
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root'); //username aka UXXXXXXXXXX student number
define('DB_PASSWORD', '19628288');  //myphp password thats in wheatley dbpassword file
define('DB_DATABASE', 'hoop_db'); //db name in the myphp


$mysqli = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_DATABASE);

if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}
