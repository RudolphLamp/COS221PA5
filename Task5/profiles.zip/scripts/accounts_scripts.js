const profile_picture = "../resources/images/profile_icon.webp";
// Mock current user_account
let currentUser = {
  User_ID: 1,
  First_Name: "John Doe",
  Last_Name: "Doe",
  Date_of_Birth: "1990-05-15",
  Admin_privileges: 0,
  Email_Address: "john.doe@example.com",
};

let otherProfiles = [];

//Populate the userProfile by calling the getProfiles method. replace 1 with the userID
getProfiles(currentUser.User_ID);

// Function to render profiles
function renderProfiles() {
  const profileList = document.getElementById("profileList");
  profileList.innerHTML = "";

  otherProfiles.forEach((profile) => {
    const profileItem = document.createElement("div");
    profileItem.classList.add("profile-item");
    profileItem.innerHTML = `
      <img src="${profile_picture}" alt="Profile Picture">
      <div class="profile-details">
        <h2>${profile.Profile_Name}</h2>
        ${
          profile.Child_Profile
            ? "<p>Child Profile</p>"
            : "<p>Adult Profile</p>"
        }
        ${
          profile.Profile_ID === currentUser.User_ID
            ? "<p style='color:light-blue;font-size:2rem;'>Current</p>"
            : ""
        }
        ${
          profile.Profile_ID !== currentUser.User_ID
            ? `<button class="edit-profile-btn" onclick="editProfile(${profile.Profile_ID})">Edit</button>
               <button class="delete-profile-btn" onclick="deleteProfile(${profile.Profile_ID})">Delete</button>`
            : ""
        }
      </div>
    `;
    profileList.appendChild(profileItem);
  });

  // Do not allow the user to add more than 4 profiles
  if (otherProfiles.length < 4) {
    const addProfileButton = document.createElement("div");
    addProfileButton.classList.add("add-profile");
    addProfileButton.onclick = addProfile;
    addProfileButton.innerHTML = `
      <span style="font-size: 24px">+</span>
    `;
    profileList.appendChild(addProfileButton);
  }
}

// Function to add a new profile
function addProfile() {
  // Mocking form inputs for profile details
  const profileName = prompt("Enter profile name:");
  if (profileName !== null) {
    const isChildProfile = confirm("Is this a child profile?");
    const languageID = prompt("Enter the language ID for the new profile");

    // Creating the new profile object
    const newProfile = {
      Profile_Name: profileName,
      User_ID: currentUser.User_ID,
      Child_Profile: isChildProfile ? 1 : 0,
      LanguageID: languageID,
    };

    addProfileRequest(newProfile);
  }
}

// Function to edit a profile
function editProfile(profileID) {
  const profileIndex = otherProfiles.findIndex(
    (profile) => profile.Profile_ID === profileID
  );
  if (profileIndex !== -1) {
    const newProfileName = prompt(
      "Enter new profile name:",
      otherProfiles[profileIndex].Profile_Name
    );
    const isChildProfile = confirm("Is this a child profile?");

    // Update the profile details
    otherProfiles[profileIndex].Profile_Name = newProfileName;
    otherProfiles[profileIndex].Child_Profile = isChildProfile ? 1 : 0;

    updateProfileRequest(profileID, newProfileName, isChildProfile);
    // Update the UI after deletion
    renderProfiles();
  }
}

// Function to delete a profile
function deleteProfile(profileID) {
  const confirmDelete = confirm(
    "Are you sure you want to delete this profile?"
  );
  if (confirmDelete) {
    // Find the index of the profile to be deleted
    const profileIndex = otherProfiles.findIndex(
      (profile) => profile.Profile_ID === profileID
    );

    // If profile exists, remove it from the array
    if (profileIndex !== -1) {
      // make request to remove it
      removeProfileRequest(profileIndex);

      //remove it from the array
      otherProfiles.splice(profileIndex, 1);
    }
  }
}

//Make request
function getProfiles(id) {
  var xmlReq = new XMLHttpRequest();
  var url = "https://wheatley.cs.up.ac.za/uXXXXXXXX/COS221/api.php"; //make sure you replace this with the path to api in your wheatley

  xmlReq.open("POST", url, true);
  xmlReq.setRequestHeader("Content-Type", "application/json");
  xmlReq.setRequestHeader(
    "Authorization",
    "Basic " + btoa("uXXXXXXXX:WheatleyPassword") //make sure you replace these with your details
  );

  xmlReq.onreadystatechange = function () {
    if (xmlReq.readyState === XMLHttpRequest.DONE) {
      if (xmlReq.status === 200) {
        var response = JSON.parse(xmlReq.responseText);
        if (response.status === 200) {
          otherProfiles = response.data;
          renderProfiles(); //render profiles after every successful request
          //   console.log(otherProfiles);
        } else {
          console.error("Error retrieving profile:", response.message);
        }
      } else {
        console.error("Error retrieving profile. HTTP status:", xmlReq.status);
      }
    }
  };

  xmlReq.onerror = function () {
    console.error("Error occurred while loading profile.");
  };

  var requestBody = {
    type: "getProfiles",
    userID: id,
  };

  xmlReq.send(JSON.stringify(requestBody));
}

//Make request
function updateProfileRequest(id, name, child) {
  var xmlReq = new XMLHttpRequest();
  var url = "https://wheatley.cs.up.ac.za/uXXXXXXXX/COS221/api.php";

  xmlReq.open("POST", url, true);
  xmlReq.setRequestHeader("Content-Type", "application/json");
  xmlReq.setRequestHeader(
    "Authorization",
    "Basic " + btoa("uXXXXXXXX:WheatleyPassword")
  );

  xmlReq.onreadystatechange = function () {
    if (xmlReq.readyState === XMLHttpRequest.DONE) {
      if (xmlReq.status === 200) {
        var response = JSON.parse(xmlReq.responseText);
        if (response.status === 200) {
          renderProfiles(); //render profiles after every successful request
          window.location.reload(); // Reload the page
        } else {
          console.error("Error retrieving profile:", response.message);
        }
      } else {
        console.error("Error retrieving profile. HTTP status:", xmlReq.status);
      }
    }
  };

  xmlReq.onerror = function () {
    console.error("Error occurred while loading profile.");
  };

  var requestBody = {
    type: "updateProfile",
    profileID: id,
    profileName: name,
    childProfile: child,
  };

  xmlReq.send(JSON.stringify(requestBody));
}

//Make request
function addProfileRequest(newProfile) {
  var xmlReq = new XMLHttpRequest();
  var url = "https://wheatley.cs.up.ac.za/uXXXXXXXX/COS221/api.php";

  xmlReq.open("POST", url, true);
  xmlReq.setRequestHeader("Content-Type", "application/json");
  xmlReq.setRequestHeader(
    "Authorization",
    "Basic " + btoa("uXXXXXXXX:WheatleyPassword")
  );

  xmlReq.onreadystatechange = function () {
    if (xmlReq.readyState === XMLHttpRequest.DONE) {
      if (xmlReq.status === 200) {
        var response = JSON.parse(xmlReq.responseText);
        if (response.status === 200) {
          renderProfiles(); //render profiles after successful addition
          window.location.reload(); // Reload the page
        } else {
          console.error("Error adding profile:", response.message);
        }
      } else {
        console.error("Error adding profile. HTTP status:", xmlReq.status);
      }
    }
  };

  xmlReq.onerror = function () {
    console.error("Error occurred while adding profile.");
  };

  var requestBody = {
    type: "addProfile",
    userID: newProfile.User_ID,
    profileName: newProfile.Profile_Name,
    childProfile: newProfile.Child_Profile,
    languageID: newProfile.LanguageID,
  };

  xmlReq.send(JSON.stringify(requestBody));
}

// Function to delete a profile
function deleteProfile(profileID) {
  const confirmDelete = confirm(
    "Are you sure you want to delete this profile?"
  );
  if (confirmDelete) {
    // make request to remove it
    removeProfileRequest(profileID);
  }
}

//Make request
function removeProfileRequest(profileID) {
  var xmlReq = new XMLHttpRequest();
  var url = "https://wheatley.cs.up.ac.za/uXXXXXXXX/COS221/api.php";

  xmlReq.open("POST", url, true);
  xmlReq.setRequestHeader("Content-Type", "application/json");
  xmlReq.setRequestHeader(
    "Authorization",
    "Basic " + btoa("uXXXXXXXX:WheatleyPassword")
  );

  xmlReq.onreadystatechange = function () {
    if (xmlReq.readyState === XMLHttpRequest.DONE) {
      if (xmlReq.status === 200) {
        var response = JSON.parse(xmlReq.responseText);
        if (response.status === 200) {
          // Remove the profile from otherProfiles array
          const profileIndex = otherProfiles.findIndex(
            (profile) => profile.Profile_ID === profileID
          );
          if (profileIndex !== -1) {
            otherProfiles.splice(profileIndex, 1);
            renderProfiles(); //render profiles after successful removal
          }
        } else {
          console.error("Error removing profile:", response.message);
        }
      } else {
        console.error("Error removing profile. HTTP status:", xmlReq.status);
      }
    }
  };

  xmlReq.onerror = function () {
    console.error("Error occurred while removing profile.");
  };

  var requestBody = {
    type: "removeProfile",
    profileID: profileID, // Correctly pass the profile ID
  };

  xmlReq.send(JSON.stringify(requestBody));
}
